import { getUncachableGitHubClient, getGitHubToken } from '../server/github-client';
import { execSync } from 'child_process';

async function createRepoAndPush() {
  console.log('Getting GitHub client...');
  const octokit = await getUncachableGitHubClient();
  
  console.log('Getting authenticated user...');
  const { data: user } = await octokit.users.getAuthenticated();
  console.log(`Authenticated as: ${user.login}`);
  
  const repoName = 'vaultkey-wallet';
  
  console.log(`Creating repository: ${repoName}...`);
  try {
    const { data: repo } = await octokit.repos.createForAuthenticatedUser({
      name: repoName,
      description: 'VaultKey - Multi-chain cryptocurrency hardware wallet',
      private: false,
      auto_init: false
    });
    console.log(`Repository created: ${repo.html_url}`);
  } catch (error: any) {
    if (error.status === 422) {
      console.log('Repository already exists, will push to existing repo');
    } else {
      throw error;
    }
  }
  
  const token = await getGitHubToken();
  const remoteUrl = `https://${token}@github.com/${user.login}/${repoName}.git`;
  
  console.log('Configuring git...');
  try {
    execSync('git config user.email "replit@users.noreply.github.com"', { stdio: 'inherit' });
    execSync('git config user.name "Replit Agent"', { stdio: 'inherit' });
  } catch (e) {
    console.log('Git config already set');
  }
  
  console.log('Adding remote...');
  try {
    execSync(`git remote add github "${remoteUrl}"`, { stdio: 'pipe' });
  } catch (e) {
    execSync(`git remote set-url github "${remoteUrl}"`, { stdio: 'pipe' });
  }
  
  console.log('Pushing to GitHub...');
  execSync('git push -u github main --force', { stdio: 'inherit' });
  
  console.log(`\nSuccess! Repository: https://github.com/${user.login}/${repoName}`);
  console.log('GitHub Actions will now build the Android APK automatically.');
}

createRepoAndPush().catch(console.error);
