import { getUncachableGitHubClient } from '../server/github-client';
import * as fs from 'fs';
import * as path from 'path';

const REPO_OWNER = 'vishnuvardanbnr-cmyk';
const REPO_NAME = 'vaultkey-wallet';

const IGNORE_PATTERNS = [
  'node_modules',
  '.git',
  'dist',
  '.cache',
  '.replit',
  'replit.nix',
  '.config',
  '.upm',
  'android/app/build',
  'android/.gradle',
  'android/build',
  'android/.idea',
  'android/local.properties',
  '*.log',
  '.DS_Store',
  'scripts/create-github-repo.ts',
  'scripts/push-to-github.ts',
  'package-lock.json'
];

function shouldIgnore(filePath: string): boolean {
  for (const pattern of IGNORE_PATTERNS) {
    if (pattern.startsWith('*')) {
      if (filePath.endsWith(pattern.slice(1))) return true;
    } else if (filePath.includes(pattern)) {
      return true;
    }
  }
  return false;
}

function getAllFiles(dir: string, baseDir: string = ''): { path: string; content: string }[] {
  const files: { path: string; content: string }[] = [];
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    const relativePath = path.join(baseDir, entry.name);
    
    if (shouldIgnore(relativePath)) continue;
    
    if (entry.isDirectory()) {
      files.push(...getAllFiles(fullPath, relativePath));
    } else if (entry.isFile()) {
      try {
        const content = fs.readFileSync(fullPath);
        const base64 = content.toString('base64');
        files.push({ path: relativePath, content: base64 });
      } catch (e) {
        console.log(`Skipping ${relativePath}: cannot read`);
      }
    }
  }
  
  return files;
}

async function pushToGitHub() {
  console.log('Getting GitHub client...');
  const octokit = await getUncachableGitHubClient();
  
  console.log('Initializing repository with README...');
  try {
    await octokit.repos.createOrUpdateFileContents({
      owner: REPO_OWNER,
      repo: REPO_NAME,
      path: 'README.md',
      message: 'Initial commit',
      content: Buffer.from('# VaultKey Wallet\n\nMulti-chain cryptocurrency hardware wallet application.\n').toString('base64')
    });
    console.log('Repository initialized');
  } catch (e: any) {
    if (e.status !== 422) throw e;
    console.log('README already exists');
  }
  
  await new Promise(r => setTimeout(r, 2000));
  
  console.log('Collecting files...');
  const files = getAllFiles('.');
  console.log(`Found ${files.length} files to push`);
  
  console.log('Creating blobs...');
  const batchSize = 10;
  const blobs: any[] = [];
  
  for (let i = 0; i < files.length; i += batchSize) {
    const batch = files.slice(i, i + batchSize);
    console.log(`Processing batch ${Math.floor(i/batchSize) + 1}/${Math.ceil(files.length/batchSize)}...`);
    
    const batchResults = await Promise.all(
      batch.map(async (file) => {
        try {
          const { data } = await octokit.git.createBlob({
            owner: REPO_OWNER,
            repo: REPO_NAME,
            content: file.content,
            encoding: 'base64'
          });
          return { path: file.path, sha: data.sha, mode: '100644' as const, type: 'blob' as const };
        } catch (e) {
          console.log(`Failed to create blob for ${file.path}`);
          return null;
        }
      })
    );
    blobs.push(...batchResults.filter(b => b !== null));
  }
  
  console.log(`Created ${blobs.length} blobs`);
  
  console.log('Getting latest commit...');
  const { data: ref } = await octokit.git.getRef({
    owner: REPO_OWNER,
    repo: REPO_NAME,
    ref: 'heads/main'
  });
  const latestCommitSha = ref.object.sha;
  
  console.log('Creating tree...');
  const { data: tree } = await octokit.git.createTree({
    owner: REPO_OWNER,
    repo: REPO_NAME,
    base_tree: latestCommitSha,
    tree: blobs
  });
  
  console.log('Creating commit...');
  const { data: commit } = await octokit.git.createCommit({
    owner: REPO_OWNER,
    repo: REPO_NAME,
    message: 'Add VaultKey multi-chain crypto wallet source code',
    tree: tree.sha,
    parents: [latestCommitSha]
  });
  
  console.log('Updating main branch...');
  await octokit.git.updateRef({
    owner: REPO_OWNER,
    repo: REPO_NAME,
    ref: 'heads/main',
    sha: commit.sha
  });
  
  console.log(`\nSuccess! Code pushed to: https://github.com/${REPO_OWNER}/${REPO_NAME}`);
  console.log('GitHub Actions will automatically start building the Android APK.');
  console.log('Check the Actions tab: https://github.com/${REPO_OWNER}/${REPO_NAME}/actions');
}

pushToGitHub().catch(console.error);
