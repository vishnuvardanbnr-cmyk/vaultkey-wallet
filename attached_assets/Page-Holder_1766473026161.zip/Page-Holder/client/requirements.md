## Packages
framer-motion | Subtle entry animations for the text
zod | Schema validation
react-hook-form | Form handling
@hookform/resolvers | Zod resolver for forms

## Notes
API endpoints defined in shared/routes
Style direction: Minimalist plain text, raw aesthetic, no decorative elements
Font: JetBrains Mono / Monospace for the raw feel
